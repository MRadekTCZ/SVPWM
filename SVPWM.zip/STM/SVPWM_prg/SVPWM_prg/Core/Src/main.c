/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
#include <math.h>
#include <string.h>
#include "lcd_i2c.h"
#include "sin_lookup.h"
#define PI 3.141592653//;
#define one_by_sqrt6 0.40824829
#define one_by_sqrt2 0.70710678
#define sqrt2_by_sqrt3 0.816496581
#define pi_by_3 1.04719755
#define Ts 0.00001
#define Timp 0.0004
float u_alfa;
float u_beta;
float u_zero; //zero U can be added if assymetry
float angle; //actual angle of PLL alfa beta vectors
int sektor; // actual sector of PLL angle (1 of 6);
float u_alfa_1; //part of alfa vector
float u_alfa_2; //part of beta vector
float u_beta_1;
float u_beta_2;
double i1; //2.5 kHz switching tranzistors
double t1,t2,t0;
float U_dc;
short int OUT[6][3] = {{1,0,0},{1,1,0},{0,1,0},{0,1,1},{0,0,1},{1,0,1}}; //space vectors
short int OUT0[3] = {0,0,0}; //zero vectors, 0 [0,0,0] or 7 [1,1,1]
float Magnitude; //Magnitude of sinusoid for U/f control
double time; //time counter
float frequency;
unsigned short int T1,T2,T3,T4,T5,T6;

union TState
{
struct ThyriState
{
	short unsigned int GPIO0:1;
	short unsigned int GPIO1:1;
	short unsigned int GPIO2:1;
	short unsigned int GPIO3:1;
	short unsigned int GPIO4:1;
	short unsigned int GPIO5:1;
	short unsigned int rest:10;
}GpioState;
short unsigned int GPIO16bit;
}TState16bit; //16 bit gpio bits for port C 6 ports represented by tranzistors

unsigned int state_on_off = 0;
volatile static uint16_t adc[2]; //adc read DMA
uint32_t cntrl;  //32bits for 4 bytes from UART -> remote control
uint16_t f_set;  //intiger frequency from UART, has to be divided by 10;

struct lcd_disp disp;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	U_dc = 540; //Napiecie DC, normalnie by�oby mierzone na uk�adzie posredniczaczym pomiedzy zaciskami kondensatora

	TState16bit.GpioState.rest = 0;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM10_Init();
  MX_TIM11_Init();
  MX_ADC1_Init();
  MX_TIM3_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start_IT(&htim10);
  HAL_TIM_Base_Start_IT(&htim11);
  HAL_TIM_Base_Start_IT(&htim3);

  HAL_ADC_Start_DMA(&hadc1, &adc, 2);
  HAL_UART_Transmit_IT(&huart2, "F0", strlen("F0"));
  HAL_UART_Receive_IT(&huart2, &cntrl, 4);

  disp.addr=(0x27<<1);
  disp.bl=1;
  lcd_init(&disp);
  lcd_clear(&disp);
  sprintf((char *)disp.f_line,"STARTING");
  HAL_Delay(2000);
  lcd_display(&disp);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if(state_on_off)
	  {
		  sprintf((char *)disp.f_line,"INV ON freq:%d", f_set);
		  HAL_Delay(200);
		  lcd_display(&disp);

	  }
	  else if (!state_on_off)
	  {
		  sprintf((char *)disp.f_line,"INV OFF freq:%d", f_set);
		  HAL_Delay(200);
		  lcd_display(&disp);
	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART2)
	{

			//zapalic / zgasic diode

		if (cntrl == 0x31314141) //Start command AA11
		{
		state_on_off = 1;
		HAL_UART_Transmit_IT(&huart2, "A1", strlen("A1")); // confirm sending message

		}
		else if (cntrl == 0x32324141) //Off command AA22
		{
		state_on_off = 0;
		HAL_UART_Transmit_IT(&huart2, "A2", strlen("A2")); // confirm sending message

		}
		else if ((cntrl|0xFFFF0000) == 0xFFFF4242) //If command BB -> Set speed 0 - 156 //BB(speed - 2 marks)
		{
			if (cntrl >= 0x64004242)
			{
				HAL_UART_Transmit_IT(&huart2, "F1", strlen("F1")); //Error 1 - freq set error

			}
			else
			{
			//f_set = (cntrl&0xFFFF0000)>>16;
			//f_set = (f_set|0xF0)>>1 + (f_set|0x0F)<<1; // frequency is set directrly in bits in range from 0 to 500 (f range 0 to 50.0 with 0.1 change possibility)
			//f = f_set*0.1;
			f_set = ((cntrl&0xFF000000)>>24) - 48;
			frequency = f_set;
			//Te czesc projektu mozna by rozszerzyc o konwerter string -> int
			HAL_UART_Transmit_IT(&huart2, "A3", strlen("A3")); //command set freq ok
			}
		}
		state_on_off ? HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET) : HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
		HAL_UART_Receive_IT(&huart2, &cntrl, 4);

	}

}
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	/*testowanie lacznosci - miganie diody z roznymi czestotliwosciami */
	//Timer for switching transistors 2,5 kHz

	if(htim->Instance == TIM10)
	{


		if ( state_on_off && frequency > 0.5)
		{


		Magnitude = frequency*0.02*330;
		//transformacja Clarka
		time = time + 0.0004;

		u_alfa = Magnitude*sin(2*PI*frequency*time);
		u_beta=Magnitude*cos(2*PI*frequency*time);
		angle=atan2f(u_beta,u_alfa);

		if(angle<0) angle=angle+2*PI; // shift 2pi for negative values

		sektor=floor(angle);
		switch (sektor)
				{
				case 0:
					u_alfa_1=sqrt2_by_sqrt3*U_dc;
					u_beta_1=0;
					u_alfa_2=one_by_sqrt6*U_dc;
					u_beta_2=one_by_sqrt2*U_dc;

					break;
				case 1:
					u_alfa_1=one_by_sqrt6*U_dc;
					u_beta_1=one_by_sqrt2*U_dc;
					u_alfa_2=-one_by_sqrt6*U_dc;
					u_beta_2=one_by_sqrt2*U_dc;
					break;
				case 2:
					u_alfa_1=-one_by_sqrt6*U_dc;
					u_beta_1=one_by_sqrt2*U_dc;
					u_alfa_2=-sqrt2_by_sqrt3*U_dc;
					u_beta_2=0;
					break;
				case 3:
					u_alfa_1=-sqrt2_by_sqrt3*U_dc;
					u_beta_1=0;
					u_alfa_2=-one_by_sqrt6*U_dc;
					u_beta_2=-one_by_sqrt2*U_dc;
					break;
				case 4:
					u_alfa_1=-one_by_sqrt6*U_dc;
					u_beta_1=-one_by_sqrt2*U_dc;
					u_alfa_2=one_by_sqrt6*U_dc;
					u_beta_2=-one_by_sqrt2*U_dc;
					break;
				case 5:
					u_alfa_1=one_by_sqrt6*U_dc;
					u_beta_1=-one_by_sqrt2*U_dc;
					u_alfa_2=sqrt2_by_sqrt3*U_dc;
					u_beta_2=0;
					break;
				}
		t1 =	Timp*( u_alfa*u_beta_2-u_beta*u_alfa_2)/(u_alfa_1*u_beta_2-u_beta_1*u_alfa_2);
		t2 = 	Timp*( -u_alfa*u_beta_1+u_beta*u_alfa_1)/(u_alfa_1*u_beta_2-u_beta_1*u_alfa_2);
		t0 = Timp - t1 - t2;
		//T1 -> GPIOC 0
		//T2 -> GPIOC 2
		//T3 -> GPIOC 4
		//T4 -> GPIOC 1
		//T5-> GPIOC 3
		//T6 -> GPIOC 5
		TState16bit.GpioState.GPIO0 = T1;
		TState16bit.GpioState.GPIO1 = T4;
		TState16bit.GpioState.GPIO2 = T2;
		TState16bit.GpioState.GPIO3 = T5;
		TState16bit.GpioState.GPIO4 = T3;
		TState16bit.GpioState.GPIO5 = T6;

		HAL_GPIO_WritePin(GPIOC, (0xFFFF) , GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOC, (TState16bit.GPIO16bit) , GPIO_PIN_SET);
		}
		else HAL_GPIO_WritePin(GPIOC, (0xFFFF) , GPIO_PIN_RESET);


	}
	////Timer for couting and interrupting 100 kHz
	if(htim->Instance == TIM11)
	{

		//Obliczanie aktualnego optymalnego wektora zerowego - aby prze��cza� jak najmniej tranzystor�w
		if ((T1+T2+T3)== 2)
		{
		OUT0[0]=1;
		OUT0[1]=1;
		OUT0[2]=1;
		}
		else if ((T1+T2+T3)== 1)
		{
		OUT0[0]=0;
		OUT0[1]=0;
		OUT0[2]=0;
		}

		if (i1<=t1)
		{
		T1 = OUT[sektor][0];
		T4 = !OUT[sektor][0];
		T2 = OUT[sektor][1];
		T5 = !OUT[sektor][1];
		T3 = OUT[sektor][2];
		T6 = !OUT[sektor][2];
		}
		else if (i1<=t1+t2)
		{
		if (sektor==5)
		{
		T1 = OUT[0][0];
		T4 = !OUT[0][0];
		T2 = OUT[0][1];
		T5 = !OUT[0][1];
		T3 = OUT[0][2];
		T6 = !OUT[0][2];
		}
		else
		{
		T1 = OUT[sektor+1][0];
		T4 = !OUT[sektor+1][0];
		T2 = OUT[sektor+1][1];
		T5 = !OUT[sektor+1][1];
		T3 = OUT[sektor+1][2];
		T6 = !OUT[sektor+1][2];
		}
		}
		else if (i1<=Timp)
		{
		T1 = OUT0[0];
		T4 = !OUT0[0];
		T2 = OUT0[1];
		T5 = !OUT0[1];
		T3 = OUT0[2];
		T6 = !OUT0[2];
		}
		else if (i1<=Timp+t2)
		{
		if (sektor==5)
		{
		T1 = OUT[0][0];
		T4 = !OUT[0][0];
		T2 = OUT[0][1];
		T5 = !OUT[0][1];
		T3 = OUT[0][2];
		T6 = !OUT[0][2];

		}
		else
		{
		T1 = OUT[sektor+1][0];
		T4 = !OUT[sektor+1][0];
		T2 = OUT[sektor+1][1];
		T5 = !OUT[sektor+1][1];
		T3 = OUT[sektor+1][2];
		T6 = !OUT[sektor+1][2];
		}
		}
		else if (i1<=Timp+t2+t1)
		{
		T1 = OUT[sektor][0];
		T4 = !OUT[sektor][0];
		T2 = OUT[sektor][1];
		T5 = !OUT[sektor][1];
		T3 = OUT[sektor][2];
		T6 = !OUT[sektor][2];
		}
		else if (i1<=2*Timp)
		{
		T1 = OUT0[0];
		T4 = !OUT0[0];
		T2 = OUT0[1];
		T5 = !OUT0[1];
		T3 = OUT0[2];
		T6 = !OUT0[2];
		}
		i1=i1+Ts;
		if (i1>=2*Timp)
		{
		i1=0;
		}



	}

}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_pin)
{
	if(GPIO_pin == GPIO_PIN_13)
	{
		state_on_off = 1;
	}
	if(GPIO_pin == GPIO_PIN_14)
	{
		state_on_off = 0;
	}
	if(GPIO_pin == GPIO_PIN_15)
	{

		frequency=adc[0]*0.014648; //set frequency from 0 to 60 Hz
	}
	state_on_off ? HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET) : HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
}

#ifdef SINLUT
unsigned int SLT_sinus(unsigned int time)
{
	return slt[time];
}
#endif
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
