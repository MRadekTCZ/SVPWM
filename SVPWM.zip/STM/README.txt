1. Jeżeli FPGA jest zdefiniowane, to SVPWM wykonuje FPGA. Odciąża to procesor i umożliwia dodanie sensownych deadtimów. STM32 pełni rolę algorytmu nadrzędnego i regulacji. Może zostać w nim zaimplementowany np. algorytm FOC lub zwykły PID czy softstart.

2. Jeżeli FPGA nie jest zdefiniowane, algorytm nadrzędny (np. PID, softstart) o częstotliwości 100 Hz nie działa, bo praca SVPWM ciągle go przerywa. Działa natomiast sztywne zadawanie innej częstotliwości. 
Ogólnie jest problem z obciążeniem mikroprocesora.
Częstotliwość obliczania sin,cos i atan2 : 2kHz
Częstotliwość licznika impulsów : 100 kHz -> częstotliwość kluczowania tranzystorów 3*Timp = 6kHz


3. Sposoby optymalizacji:
sin,cos zrobić jako lookup
iterowanie zamiast przez czas we float to jako inkrementalną zmienną typu int
PLL lookup narastający liniowo